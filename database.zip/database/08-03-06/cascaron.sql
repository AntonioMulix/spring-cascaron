--
-- PostgreSQL database dump
--

\restrict dgXFXHWnFox4KI68TVDAjVhBF50R1bFcZhn9iN8o9LJkLO4Zjh0CmR10Siw9Ap6

-- Dumped from database version 18.1 (Ubuntu 18.1-1.pgdg24.04+2)
-- Dumped by pg_dump version 18.1 (Ubuntu 18.1-1.pgdg24.04+2)

-- Started on 2026-03-08 16:45:10 CST

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 221 (class 1259 OID 16633)
-- Name: admin_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin_log (
    log_id bigint NOT NULL,
    type character varying(255) NOT NULL,
    operation character varying(255) NOT NULL,
    remote_addr character varying(255) NOT NULL,
    request_uri character varying(255) NOT NULL,
    method character varying(255) NOT NULL,
    params character varying(255),
    operate_date timestamp(6) without time zone NOT NULL,
    user_id integer,
    user_name character varying(255),
    result_params character varying(255) NOT NULL,
    exception_log character varying(255) NOT NULL
);


ALTER TABLE public.admin_log OWNER TO postgres;

--
-- TOC entry 222 (class 1259 OID 16650)
-- Name: admin_log_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.admin_log ALTER COLUMN log_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.admin_log_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 219 (class 1259 OID 16607)
-- Name: usuarios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuarios (
    id bigint NOT NULL,
    nombre character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    estatus integer NOT NULL
);


ALTER TABLE public.usuarios OWNER TO postgres;

--
-- TOC entry 220 (class 1259 OID 16632)
-- Name: usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.usuarios ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.usuarios_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 3463 (class 0 OID 16633)
-- Dependencies: 221
-- Data for Name: admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admin_log (log_id, type, operation, remote_addr, request_uri, method, params, operate_date, user_id, user_name, result_params, exception_log) FROM stdin;
6	obtuvo lista de todos los  usuarios	listarUsuarios	127.0.1.1	/usuarios/listarUsuarios	GET	\N	2026-03-08 14:59:43.325429	\N	\N	<200 OK OK,OutputEntity(code=200 OK, messages=[Proceso exitoso.], error=0, data=[com.example.cascaron.entity.Usuarios@5fb349c]),[]>	Sin anormalidad
\.


--
-- TOC entry 3461 (class 0 OID 16607)
-- Dependencies: 219
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuarios (id, nombre, email, estatus) FROM stdin;
3	Marco Romero	marco.romero@gmail.com	1
\.


--
-- TOC entry 3470 (class 0 OID 0)
-- Dependencies: 222
-- Name: admin_log_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.admin_log_log_id_seq', 6, true);


--
-- TOC entry 3471 (class 0 OID 0)
-- Dependencies: 220
-- Name: usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuarios_id_seq', 3, true);


--
-- TOC entry 3313 (class 2606 OID 16675)
-- Name: admin_log admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_log
    ADD CONSTRAINT admin_log_pkey PRIMARY KEY (log_id);


--
-- TOC entry 3311 (class 2606 OID 16660)
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


-- Completed on 2026-03-08 16:45:10 CST

--
-- PostgreSQL database dump complete
--

\unrestrict dgXFXHWnFox4KI68TVDAjVhBF50R1bFcZhn9iN8o9LJkLO4Zjh0CmR10Siw9Ap6

